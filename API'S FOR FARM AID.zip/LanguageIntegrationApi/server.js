require("dotenv").config();
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const axios = require("axios");

const app = express();
const PORT = 4000;

// Middleware
app.use(bodyParser.json());
app.use(cors()); // Enable Cross-Origin Resource Sharing

// Translation Function
const translateText = async (text, targetLanguage) => {
  try {
    // Replace with your translation API endpoint
    const apiKey = process.env.TRANSLATION_API_KEY; 
    const endpoint = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
      text
    )}&langpair=en|${targetLanguage}`;

    const response = await axios.get(endpoint);
    const translatedText = response.data.responseData.translatedText;
    return translatedText;
  } catch (error) {
    console.error("Error translating text:", error.message);
    throw new Error("Translation failed");
  }
};

// API Endpoint
app.post("/translate", async (req, res) => {
  const { text, language } = req.body;
  const languageMap = {
    yoruba: "yo",
    igbo: "ig",
    hausa: "ha",
    english: "en",
  };

  const targetLanguage = languageMap[language.toLowerCase()];
  if (!targetLanguage) {
    return res.status(400).json({ error: "Unsupported language" });
  }

  try {
    const translatedText = await translateText(text, targetLanguage);
    res.json({ translatedText });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
