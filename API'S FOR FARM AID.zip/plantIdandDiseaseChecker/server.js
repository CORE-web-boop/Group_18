require("dotenv").config();
const express = require("express");
const multer = require("multer");
const bodyParser = require("body-parser");
const fs = require("fs");
const axios = require("axios");

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Configure Multer for file uploads
const upload = multer({ dest: "uploads/" }); // Uploaded files are saved in the "uploads" folder

// Identify Plant Function
const identifyPlant = async (imageBase64) => {
  const apiKey = process.env.PLANT_ID_API_KEY; // Your Plant.id API key
  const endpoint = "https://api.plant.id/v2/identify";

  try {
    const response = await axios.post(
      endpoint,
      {
        api_key: apiKey,
        images: [imageBase64],
        plant_details: ["common_names", "diseases"],
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.suggestions[0]; // Return the first suggestion
  } catch (error) {
    console.error("Error identifying plant:", error.message);
    throw new Error("Failed to identify plant. Please try again.");
  }
};

// Image Upload Route
app.post("/upload", upload.single("image"), async (req, res) => {
  try {
    const imagePath = req.file.path; // Get the file path from multer
    const imageBase64 = fs.readFileSync(imagePath, { encoding: "base64" }); // Convert the image to Base64

    // Call the Plant.id API
    const plantDetails = await identifyPlant(imageBase64);

    // Cleanup: Delete the uploaded file
    fs.unlinkSync(imagePath);

    // Send the plant details back to the user
    res.json({
      success: true,
      data: plantDetails,
    });
  } catch (error) {
    console.error("Error handling upload:", error.message);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
